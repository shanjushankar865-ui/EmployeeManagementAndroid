# Employee Management Android App

## Firebase project
This project is configured for the Firebase Android app package:
`com.employee.managment`

Important: this spelling (`managment`) exactly matches the package name in the Firebase JSON you supplied. It differs from `com.employee.management` previously mentioned. Do not change it unless you register a second Android app in Firebase with the corrected package.

## Open and build
1. Install Android Studio (latest stable) and Android SDK 35.
2. Extract this ZIP.
3. Open the extracted `EmployeeManagementAndroid` folder in Android Studio.
4. Wait for Gradle sync. If prompted, install missing SDK/build tools.
5. Connect an Android phone with USB debugging enabled, or use an emulator, then press Run.
6. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Firestore
The app stores records in the `employees` collection and supports add, list, search, edit and delete.
Expiry values must be entered as `YYYY-MM-DD`.

## Important security step before real use
Your Firestore is in production mode, so reads/writes will be denied until you configure Authentication and secure Firestore Rules. Do not switch to open public rules for a real employee database. Add Firebase Authentication (for example, admin sign-in) and restrict the `employees` collection to authenticated authorized users before using real employee data.

This starter app currently has no sign-in screen, employee photo upload, or role-based access. Those should be added before production deployment. The Firebase config file is included because you supplied it; it contains project identifiers and a client API key, not an admin private key.
