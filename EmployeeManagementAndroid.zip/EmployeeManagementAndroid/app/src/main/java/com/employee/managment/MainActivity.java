package com.employee.managment;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private FirebaseFirestore db;
    private LinearLayout root, list;
    private EditText name, employeeId, passport, passportExpiry, visa, visaExpiry, search;
    private TextView status;
    private final ArrayList<DocumentSnapshot> employees = new ArrayList<>();
    private String editingId = null;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try { FirebaseApp.initializeApp(this); db = FirebaseFirestore.getInstance(); }
        catch (Exception e) { Toast.makeText(this, "Firebase setup error: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
        buildUi();
        loadEmployees();
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(35,48,43)); if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 8, 0, 8); return t;
    }
    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setInputType(type);
        e.setPadding(22, 12, 22, 12); return e;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setOnClickListener(v -> action.run()); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 28); root.setBackgroundColor(Color.rgb(246,249,247));
        scroll.addView(root); setContentView(scroll);
        TextView title = text("Employee Management", 25, true); title.setTextColor(Color.rgb(18,75,61)); root.addView(title);
        root.addView(text("Firebase • Employee records", 14, false));
        status = text("Connecting to Firebase…", 13, false); root.addView(status);
        root.addView(text("Employee Details", 19, true));
        name = field("Employee name", InputType.TYPE_CLASS_TEXT); root.addView(name);
        employeeId = field("Employee ID", InputType.TYPE_CLASS_TEXT); root.addView(employeeId);
        passport = field("Passport number", InputType.TYPE_CLASS_TEXT); root.addView(passport);
        passportExpiry = field("Passport expiry (YYYY-MM-DD)", InputType.TYPE_CLASS_DATETIME); root.addView(passportExpiry);
        visa = field("Visa / Qatar ID number", InputType.TYPE_CLASS_TEXT); root.addView(visa);
        visaExpiry = field("Visa / ID expiry (YYYY-MM-DD)", InputType.TYPE_CLASS_DATETIME); root.addView(visaExpiry);
        root.addView(button("Save Employee", this::saveEmployee));
        root.addView(button("Clear Form", this::clearForm));
        root.addView(text("Employee Directory", 20, true));
        search = field("Search name, ID or passport", InputType.TYPE_CLASS_TEXT); root.addView(search);
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ renderEmployees(s.toString()); }
            public void afterTextChanged(android.text.Editable e){}
        });
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
    }
    private void saveEmployee() {
        if (db == null) { status.setText("Firebase is not initialized."); return; }
        String n=name.getText().toString().trim(), id=employeeId.getText().toString().trim();
        if (n.isEmpty() || id.isEmpty()) { Toast.makeText(this,"Name and Employee ID are required",Toast.LENGTH_SHORT).show(); return; }
        Map<String,Object> data = new HashMap<>();
        data.put("name",n); data.put("employeeId",id); data.put("passportNumber",passport.getText().toString().trim());
        data.put("passportExpiry",passportExpiry.getText().toString().trim()); data.put("visaNumber",visa.getText().toString().trim());
        data.put("visaExpiry",visaExpiry.getText().toString().trim()); data.put("updatedAt", FieldValue.serverTimestamp());
        if (editingId == null) data.put("createdAt", FieldValue.serverTimestamp());
        String doc = editingId == null ? db.collection("employees").document().getId() : editingId;
        db.collection("employees").document(doc).set(data).addOnSuccessListener(v -> {
            Toast.makeText(this,"Employee saved",Toast.LENGTH_SHORT).show(); clearForm(); loadEmployees();
        }).addOnFailureListener(e -> status.setText("Save failed: " + e.getMessage()));
    }
    private void clearForm() {
        editingId=null; name.setText(""); employeeId.setText(""); passport.setText("");
        passportExpiry.setText(""); visa.setText(""); visaExpiry.setText("");
    }
    private void loadEmployees() {
        if (db == null) return;
        db.collection("employees").addSnapshotListener((snap, err) -> {
            if (err != null) { status.setText("Database error: " + err.getMessage()); return; }
            employees.clear(); if (snap != null) employees.addAll(snap.getDocuments());
            status.setText("Connected • " + employees.size() + " employee(s)");
            renderEmployees(search == null ? "" : search.getText().toString());
        });
    }
    private void renderEmployees(String q) {
        if (list == null) return; list.removeAllViews(); String query=q.toLowerCase(Locale.ROOT);
        for (DocumentSnapshot d: employees) {
            String n=d.getString("name"), id=d.getString("employeeId"), p=d.getString("passportNumber");
            String hay=((n==null?"":n)+" "+(id==null?"":id)+" "+(p==null?"":p)).toLowerCase(Locale.ROOT);
            if (!hay.contains(query)) continue;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(18,14,18,14); card.setBackgroundColor(Color.WHITE);
            TextView heading=text((n==null?"Unnamed":n)+"  •  "+(id==null?"":id),17,true); card.addView(heading);
            String pe=d.getString("passportExpiry"), ve=d.getString("visaExpiry");
            card.addView(text("Passport: "+(p==null?"—":p)+" | Expiry: "+expiryLabel(pe),13,false));
            card.addView(text("Visa / ID: "+safe(d.getString("visaNumber"))+" | Expiry: "+expiryLabel(ve),13,false));
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=new Button(this); edit.setText("Edit"); edit.setOnClickListener(v -> {
                editingId=d.getId(); name.setText(safe(n)); employeeId.setText(safe(id)); passport.setText(safe(p));
                passportExpiry.setText(safe(pe)); visa.setText(safe(d.getString("visaNumber"))); visaExpiry.setText(safe(ve));
                root.smoothScrollTo(0,0);
            });
            Button del=new Button(this); del.setText("Delete"); del.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
                .setTitle("Delete employee?").setMessage("This record will be permanently deleted.")
                .setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->db.collection("employees").document(d.getId()).delete()
                .addOnFailureListener(e->status.setText("Delete failed: "+e.getMessage()))).show());
            actions.addView(edit); actions.addView(del); card.addView(actions);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,10,0,10); list.addView(card,lp);
        }
    }
    private String safe(String s){return s==null?"":s;}
    private String expiryLabel(String date) {
        if (date==null || date.trim().isEmpty()) return "Not entered";
        try {
            Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date.trim());
            Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
            Calendar e=Calendar.getInstance(); e.setTime(d); e.set(Calendar.HOUR_OF_DAY,0); e.set(Calendar.MINUTE,0); e.set(Calendar.SECOND,0); e.set(Calendar.MILLISECOND,0);
            long days=(e.getTimeInMillis()-c.getTimeInMillis())/86400000L;
            return days<0 ? "EXPIRED" : (days<=30 ? "EXPIRING SOON" : "VALID") + " • " + date;
        } catch(Exception ex){ return date+" (use YYYY-MM-DD)"; }
    }
}
